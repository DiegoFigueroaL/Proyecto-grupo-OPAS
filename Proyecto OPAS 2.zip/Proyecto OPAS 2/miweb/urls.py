from django.urls import path, include 
from . import views 

urlpatterns = [
    path('',views.index, name="index"),
    path('contacto',views.contacto, name="contacto"),
    path('medidas', views.medidas, name = "medidas"),
    path('formulario', views.formulario, name="formulario"),
    path('sintomasa', views.sintomasa, name="sintomasa"),
    path('sintomasb', views.sintomasb, name="sintomasb"),
    path('nosintomas', views.nosintomas, name="nosintomas"),
    path('valoracion', views.valoracion, name="valoracion"),
    path('cifras', views.cifras, name="cifras")
]
