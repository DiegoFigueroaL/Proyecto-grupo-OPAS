from django.shortcuts import render, HttpResponse, redirect

context= 0
def index(request):
    context = {"ciudad1": "Santiago", 
    "ciudad2": "Valparaiso",
    "ciudad3": "Viña del Mar"}
    return render(request, "index.html", context)

def contacto(request):
    return render(request,"contacto.html")

def medidas(request):
    return render(request, "medidas.html")

def formulario(request):
    return render(request, "formulario.html")

def sintomasa(request):
    return render(request, "sintomasa.html")

def sintomasb(request):
    return render(request, "sintomasb.html")

def nosintomas(request):
    return render(request, "nosintomas.html")

def valoracion(request):
    return render(request, "valoracion.html")

def cifras(request):
    return render(request,"cifras.html")

