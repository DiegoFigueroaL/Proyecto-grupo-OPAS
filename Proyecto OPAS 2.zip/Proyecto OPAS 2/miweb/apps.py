from django.apps import AppConfig


class MiwebConfig(AppConfig):
    name = 'miweb'
